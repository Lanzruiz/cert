Images license:

Avatar		: http://pickaface.net/
Ilustration	: http://www.behance.net/maz_martin
		  http://www.behance.net/gallery/Various-Editorial-Work-I/13031337

